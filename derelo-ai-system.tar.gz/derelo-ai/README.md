# Derelo AI v0.2 – Ready-to-Run System

Multi-agent intelligence platform for live, time-synchronized analytical reports.

**Focus domains:** AI regulation · Data sharing · Social signals · Product trading · Satellite/AI infrastructure

---

## Quick Start

```bash
export DERELO_ENCRYPTION_KEY="jYLBkgiREFUXMVXr_UmA3f1utkv5EYBbsErPPJD19X4="
# Optional: export DERELO_LLM_API_KEY="your-key"

pip install -r requirements.txt
python -m uvicorn app.main:app --host 0.0.0.0 --port 8000
```

- **Dashboard:** http://localhost:8000/
- **API docs:** http://localhost:8000/docs
- **API key (full access):** `derelo-dev-prototype-key-8f3a2c1b9e0d4a76`

---

## Incorporated Advancements

| Capability              | Status     | Endpoint / Notes                          |
|-------------------------|------------|-------------------------------------------|
| Multi-agent reports     | Available  | POST /v1/reports , POST /v1/reports/advanced |
| Real web/news search    | Available  | Built into IngestionAgent                 |
| Domain specialists      | Available  | Regulation, DataSharing, Trading, Social  |
| RAG                     | Available  | POST /v1/rag/query + auto-index reports   |
| LLM analysis            | Partial    | Ready; set DERELO_LLM_API_KEY             |
| Document ingestion      | Available  | POST /v1/documents                        |
| Topic monitors          | Available  | POST /v1/monitors                         |
| Alerts                  | Available  | GET /v1/alerts                            |
| Auto evaluation         | Available  | Returned on advanced reports              |
| Encryption at rest      | Available  | Fernet via DERELO_ENCRYPTION_KEY          |
| API-key auth + scopes   | Available  | X-API-Key header                          |
| Web dashboard           | Available  | /                                         |
| Streaming               | Planned    | —                                         |
| SSO / Billing           | Planned    | —                                         |

---

## Core API Examples

### Advanced Report
```bash
curl -X POST http://localhost:8000/v1/reports/advanced \
  -H "X-API-Key: $KEY" -H "Content-Type: application/json" \
  -d '{
    "topic": "Cross-border data sharing and AI regulation",
    "use_rag": true,
    "use_llm": true,
    "template": "compliance",
    "tags": ["regulation","privacy"]
  }'
```

### RAG Query
```bash
curl -X POST http://localhost:8000/v1/rag/query \
  -H "X-API-Key: $KEY" -H "Content-Type: application/json" \
  -d '{"query":"data sharing enforcement","top_k":5}'
```

### Capabilities
```bash
curl http://localhost:8000/v1/capabilities
```

---

## Configuration

| Variable                 | Purpose                          |
|--------------------------|----------------------------------|
| DERELO_ENCRYPTION_KEY    | Encrypt report payloads at rest  |
| DERELO_LLM_API_KEY       | Enable real LLM analysis path    |
| DERELO_LLM_BASE_URL      | LLM API base                     |
| DERELO_LLM_MODEL         | Model name                       |

---

This is a cohesive, runnable system implementing the full advancement concept with working endpoints. It is a foundation for further productization, not a finished commercial/regulatory product.
