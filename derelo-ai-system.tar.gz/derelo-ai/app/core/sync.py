"""
Derelo Synchronization Layer

Provides calibrated timestamps and basic latency / quality scoring.
In a production system this would integrate with GNSS-disciplined clocks,
PTP, or high-quality time services. For the prototype we use system time
plus measured retrieval latency.
"""

from __future__ import annotations

from datetime import datetime, timezone
from typing import List
import time

from app.models.schemas import SourceItem, CalibratedDataPackage


def utc_now() -> datetime:
    return datetime.now(timezone.utc)


def calibrate_items(items: List[SourceItem], start_time: float) -> CalibratedDataPackage:
    """
    Attach calibration metadata and compute a simple sync quality score.
    """
    end_time = time.perf_counter()
    total_latency_ms = (end_time - start_time) * 1000.0

    if not items:
        return CalibratedDataPackage(
            items=[],
            calibration_timestamp=utc_now(),
            max_latency_ms=total_latency_ms,
            sync_quality=0.0,
        )

    # Simple quality heuristic:
    # - Prefer items that have a published_at timestamp
    # - Penalize high retrieval latency
    # - Reward higher individual confidence
    has_pub_ts = sum(1 for i in items if i.published_at is not None)
    avg_confidence = sum(i.confidence for i in items) / len(items)

    latency_score = max(0.0, 1.0 - (total_latency_ms / 5000.0))  # 5s = 0
    coverage_score = has_pub_ts / len(items)
    confidence_score = avg_confidence

    sync_quality = round(
        (0.4 * latency_score) + (0.3 * coverage_score) + (0.3 * confidence_score),
        3,
    )

    return CalibratedDataPackage(
        items=items,
        calibration_timestamp=utc_now(),
        max_latency_ms=round(total_latency_ms, 1),
        sync_quality=sync_quality,
    )
