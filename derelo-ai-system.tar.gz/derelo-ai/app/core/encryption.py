"""
Application-level encryption for Derelo AI.

Uses Fernet (symmetric authenticated encryption).
The key must be provided via the DERELO_ENCRYPTION_KEY environment variable.

This is standard, strong encryption. It is NOT Firebase.
Firebase security rules / Firebase App Check / Firestore encryption-at-rest
require a real Firebase project and credentials, which are not configured here.
"""

from __future__ import annotations

import os
from typing import Optional

from cryptography.fernet import Fernet, InvalidToken


class EncryptionService:
    def __init__(self, key: Optional[str] = None):
        raw = key or os.environ.get("DERELO_ENCRYPTION_KEY")
        self._fernet: Optional[Fernet] = None
        self.enabled = False

        if raw:
            try:
                self._fernet = Fernet(raw.encode() if isinstance(raw, str) else raw)
                self.enabled = True
            except Exception:
                self._fernet = None
                self.enabled = False

    def encrypt(self, plaintext: str) -> str:
        if not self.enabled or not self._fernet:
            return plaintext
        return self._fernet.encrypt(plaintext.encode("utf-8")).decode("utf-8")

    def decrypt(self, token: str) -> str:
        if not self.enabled or not self._fernet:
            return token
        try:
            return self._fernet.decrypt(token.encode("utf-8")).decode("utf-8")
        except InvalidToken:
            # Data may have been stored before encryption was enabled
            return token


# Singleton – key comes from environment
encryption = EncryptionService()


def generate_key() -> str:
    """Generate a new Fernet key (url-safe base64)."""
    return Fernet.generate_key().decode("utf-8")
