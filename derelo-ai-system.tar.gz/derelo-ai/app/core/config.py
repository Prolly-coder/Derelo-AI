from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    app_name: str = "Derelo AI"
    app_version: str = "0.1.0"
    api_prefix: str = "/v1"
    debug: bool = True

    # Report defaults
    default_max_items: int = 8
    report_ttl_hours: int = 24

    # Sync layer
    target_sync_quality: float = 0.85
    max_acceptable_latency_ms: float = 2500.0

    class Config:
        env_prefix = "DERELO_"


settings = Settings()
