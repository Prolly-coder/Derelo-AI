"""
Lightweight persistent storage for reports using SQLite.
Payloads are encrypted at rest when DERELO_ENCRYPTION_KEY is set.
"""

from __future__ import annotations

from pathlib import Path
from typing import List, Optional
from uuid import UUID

import aiosqlite

from app.models.schemas import LiveReport
from app.core.encryption import encryption


DB_PATH = Path(__file__).resolve().parents[2] / "derelo.db"


async def init_db():
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("""
            CREATE TABLE IF NOT EXISTS reports (
                report_id TEXT PRIMARY KEY,
                topic TEXT NOT NULL,
                status TEXT NOT NULL,
                created_at TEXT NOT NULL,
                completed_at TEXT,
                payload TEXT NOT NULL
            )
        """)
        await db.execute("""
            CREATE INDEX IF NOT EXISTS idx_reports_created
            ON reports(created_at DESC)
        """)
        await db.commit()


async def save_report(report: LiveReport):
    payload = report.model_dump_json()
    # Encrypt payload when encryption is enabled
    stored = encryption.encrypt(payload)

    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            """
            INSERT OR REPLACE INTO reports
            (report_id, topic, status, created_at, completed_at, payload)
            VALUES (?, ?, ?, ?, ?, ?)
            """,
            (
                str(report.report_id),
                report.topic,
                report.status.value,
                report.created_at.isoformat(),
                report.completed_at.isoformat() if report.completed_at else None,
                stored,
            ),
        )
        await db.commit()


async def get_report(report_id: UUID) -> Optional[LiveReport]:
    async with aiosqlite.connect(DB_PATH) as db:
        async with db.execute(
            "SELECT payload FROM reports WHERE report_id = ?",
            (str(report_id),),
        ) as cursor:
            row = await cursor.fetchone()
            if row:
                plain = encryption.decrypt(row[0])
                return LiveReport.model_validate_json(plain)
    return None


async def list_reports(limit: int = 20) -> List[LiveReport]:
    async with aiosqlite.connect(DB_PATH) as db:
        async with db.execute(
            """
            SELECT payload FROM reports
            ORDER BY created_at DESC
            LIMIT ?
            """,
            (limit,),
        ) as cursor:
            rows = await cursor.fetchall()
            results = []
            for r in rows:
                try:
                    plain = encryption.decrypt(r[0])
                    results.append(LiveReport.model_validate_json(plain))
                except Exception:
                    continue
            return results
