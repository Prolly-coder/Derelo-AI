"""
Simple API-key authentication for Derelo AI.

In production this would be replaced by JWT, OAuth2, or a proper identity provider.
For the prototype we use a header-based API key with optional scopes.
"""

from __future__ import annotations

import secrets
from datetime import datetime, timezone
from typing import Dict, List, Optional

from fastapi import HTTPException, Security, status
from fastapi.security import APIKeyHeader
from pydantic import BaseModel


api_key_header = APIKeyHeader(name="X-API-Key", auto_error=False)


class APIKeyRecord(BaseModel):
    key: str
    name: str
    scopes: List[str]
    created_at: datetime
    active: bool = True


# In-memory key store (replace with DB in production)
_API_KEYS: Dict[str, APIKeyRecord] = {}


def _bootstrap_keys():
    """Create stable default development keys if none exist."""
    if not _API_KEYS:
        # Fixed keys for the prototype (rotated with xAI/Grok integration update)
        dev_key = "derelo-dev-268c9bc9b2c2bd5b88568f6615ef9c7c"
        _API_KEYS[dev_key] = APIKeyRecord(
            key=dev_key,
            name="Development Key",
            scopes=["reports:read", "reports:write", "agents:read", "admin"],
            created_at=datetime.now(timezone.utc),
            active=True,
        )
        demo_key = "derelo-demo-988d78d7ded50320"
        _API_KEYS[demo_key] = APIKeyRecord(
            key=demo_key,
            name="Demo Key (read-only)",
            scopes=["reports:read", "agents:read"],
            created_at=datetime.now(timezone.utc),
            active=True,
        )


_bootstrap_keys()


def create_api_key(name: str, scopes: Optional[List[str]] = None) -> APIKeyRecord:
    key = "derelo-" + secrets.token_hex(20)
    record = APIKeyRecord(
        key=key,
        name=name,
        scopes=scopes or ["reports:read", "reports:write", "agents:read"],
        created_at=datetime.now(timezone.utc),
        active=True,
    )
    _API_KEYS[key] = record
    return record


def list_api_keys() -> List[APIKeyRecord]:
    return list(_API_KEYS.values())


def revoke_api_key(key: str) -> bool:
    if key in _API_KEYS:
        _API_KEYS[key].active = False
        return True
    return False


async def require_api_key(
    api_key: Optional[str] = Security(api_key_header),
    required_scopes: Optional[List[str]] = None,
) -> APIKeyRecord:
    if not api_key:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Missing X-API-Key header",
            headers={"WWW-Authenticate": "ApiKey"},
        )

    record = _API_KEYS.get(api_key)
    if not record or not record.active:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid or revoked API key",
            headers={"WWW-Authenticate": "ApiKey"},
        )

    if required_scopes:
        missing = [s for s in required_scopes if s not in record.scopes and "admin" not in record.scopes]
        if missing:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=f"Insufficient scopes. Missing: {missing}",
            )

    return record


# Convenience dependency factories
async def require_read(api_key: Optional[str] = Security(api_key_header)) -> APIKeyRecord:
    return await require_api_key(api_key, required_scopes=["reports:read"])


async def require_write(api_key: Optional[str] = Security(api_key_header)) -> APIKeyRecord:
    return await require_api_key(api_key, required_scopes=["reports:write"])


async def require_admin(api_key: Optional[str] = Security(api_key_header)) -> APIKeyRecord:
    return await require_api_key(api_key, required_scopes=["admin"])
