"""
Internal social layer for Derelo AI: posts + reactions.

This is an in-app collaboration feed (share report insights, react).
It does NOT post to X, LinkedIn, or other external networks unless
separate credentials and integrations are added later.
"""

from __future__ import annotations

from datetime import datetime, timezone
from typing import Dict, List, Optional
from uuid import UUID, uuid4

from pydantic import BaseModel, Field


class ReactionType(str):
    like = "like"
    insightful = "insightful"
    important = "important"
    disagree = "disagree"


ALLOWED_REACTIONS = {"like", "insightful", "important", "disagree"}


class PostCreate(BaseModel):
    author: str = Field(..., min_length=1, max_length=80)
    content: str = Field(..., min_length=1, max_length=4000)
    report_id: Optional[UUID] = None
    tags: List[str] = Field(default_factory=list)


class ReactionCreate(BaseModel):
    user: str = Field(..., min_length=1, max_length=80)
    reaction: str = Field(..., description="like | insightful | important | disagree")


class ReactionInfo(BaseModel):
    user: str
    reaction: str
    created_at: datetime


class PostInfo(BaseModel):
    post_id: UUID
    author: str
    content: str
    report_id: Optional[UUID] = None
    tags: List[str] = Field(default_factory=list)
    created_at: datetime
    reactions: List[ReactionInfo] = Field(default_factory=list)
    reaction_counts: Dict[str, int] = Field(default_factory=dict)


_POSTS: Dict[UUID, PostInfo] = {}


def _counts(reactions: List[ReactionInfo]) -> Dict[str, int]:
    c: Dict[str, int] = {}
    for r in reactions:
        c[r.reaction] = c.get(r.reaction, 0) + 1
    return c


def create_post(body: PostCreate) -> PostInfo:
    pid = uuid4()
    post = PostInfo(
        post_id=pid,
        author=body.author,
        content=body.content,
        report_id=body.report_id,
        tags=body.tags,
        created_at=datetime.now(timezone.utc),
        reactions=[],
        reaction_counts={},
    )
    _POSTS[pid] = post
    return post


def list_posts(limit: int = 30) -> List[PostInfo]:
    posts = sorted(_POSTS.values(), key=lambda p: p.created_at, reverse=True)
    return posts[:limit]


def get_post(post_id: UUID) -> Optional[PostInfo]:
    return _POSTS.get(post_id)


def add_reaction(post_id: UUID, body: ReactionCreate) -> PostInfo:
    post = _POSTS.get(post_id)
    if not post:
        raise KeyError("post_not_found")

    reaction = body.reaction.lower().strip()
    if reaction not in ALLOWED_REACTIONS:
        raise ValueError(f"Invalid reaction. Allowed: {sorted(ALLOWED_REACTIONS)}")

    # One reaction per user per post (update if exists)
    reactions = [r for r in post.reactions if r.user != body.user]
    reactions.append(
        ReactionInfo(
            user=body.user,
            reaction=reaction,
            created_at=datetime.now(timezone.utc),
        )
    )

    updated = PostInfo(
        post_id=post.post_id,
        author=post.author,
        content=post.content,
        report_id=post.report_id,
        tags=post.tags,
        created_at=post.created_at,
        reactions=reactions,
        reaction_counts=_counts(reactions),
    )
    _POSTS[post_id] = updated
    return updated


def delete_post(post_id: UUID) -> bool:
    return _POSTS.pop(post_id, None) is not None
