from __future__ import annotations

from abc import ABC, abstractmethod
from datetime import datetime
from typing import Any, Dict, Optional

from app.core.sync import utc_now
from app.models.schemas import AgentStatus, AgentTraceStep


class BaseAgent(ABC):
    name: str
    role: str
    description: str

    def __init__(self):
        self.status = AgentStatus.idle
        self.last_active: Optional[datetime] = None

    def _mark_running(self):
        self.status = AgentStatus.running
        self.last_active = utc_now()

    def _mark_idle(self):
        self.status = AgentStatus.idle
        self.last_active = utc_now()

    def _mark_error(self):
        self.status = AgentStatus.error
        self.last_active = utc_now()

    def trace(self, action: str, details: Optional[str] = None, confidence: Optional[float] = None) -> AgentTraceStep:
        return AgentTraceStep(
            agent=self.name,
            action=action,
            timestamp=utc_now(),
            details=details,
            confidence=confidence,
        )

    @abstractmethod
    async def run(self, context: Dict[str, Any]) -> Dict[str, Any]:
        """Execute the agent's task and return updated context."""
        pass
