from __future__ import annotations

from typing import Any, Dict, List

from app.agents.base import BaseAgent


DOMAIN_SIGNALS = {
    "regulation": [
        "regulation", "regulatory", "policy", "compliance", "law", "legislation",
        "governance", "oversight", "enforcement", "guideline", "standard",
    ],
    "social": [
        "social", "network", "platform", "community", "influence", "discourse",
        "coordination", "public opinion", "sentiment", "viral",
    ],
    "data_sharing": [
        "data sharing", "data exchange", "privacy", "gdpr", "data mining",
        "dataset", "provenance", "access control", "open data", "marketplace",
    ],
    "trading": [
        "trading", "market", "commerce", "product", "supply chain", "pricing",
        "transaction", "commodity", "import", "export", "demand",
    ],
    "satellite_ai": [
        "satellite", "orbital", "space-based", "earth observation", "remote sensing",
        "constellation", "starlink", "starmind", "on-orbit",
    ],
}


class AnalysisAgent(BaseAgent):
    name = "AnalysisAgent"
    role = "Cross-source & Domain Reasoning"
    description = (
        "Performs structured multi-domain analysis over calibrated data. "
        "Covers AI regulation, social signals, data sharing, product trading, "
        "and satellite/AI infrastructure themes."
    )

    async def run(self, context: Dict[str, Any]) -> Dict[str, Any]:
        self._mark_running()
        traces = context.get("trace", [])
        topic = context.get("topic", "")
        calibrated = context.get("calibrated")

        try:
            if not calibrated or not calibrated.items:
                raise ValueError("No calibrated data available for analysis")

            items = calibrated.items
            avg_conf = sum(i.confidence for i in items) / len(items)
            topic_lower = topic.lower()
            all_text = " ".join(
                (i.title + " " + i.snippet).lower() for i in items
            )

            active_domains = []
            for domain, keywords in DOMAIN_SIGNALS.items():
                score = sum(1 for kw in keywords if kw in topic_lower or kw in all_text)
                if score >= 1:
                    active_domains.append((domain, score))
            active_domains.sort(key=lambda x: x[1], reverse=True)
            domain_names = [d[0] for d in active_domains[:4]]

            key_findings: List[str] = [
                f"Processed {len(items)} calibrated source items on '{topic}'.",
                f"Average source confidence: {avg_conf:.2f}. "
                f"Synchronization quality: {calibrated.sync_quality:.2f}.",
            ]

            if domain_names:
                key_findings.append(
                    f"Primary domains detected: {', '.join(domain_names)}."
                )

            if "regulation" in domain_names:
                key_findings.append(
                    "Regulatory and policy signals are present. "
                    "Monitor for new compliance requirements, enforcement actions, "
                    "and cross-jurisdictional alignment."
                )
            if "data_sharing" in domain_names:
                key_findings.append(
                    "Data sharing / mining / provenance themes appear. "
                    "Attention to access controls, privacy constraints, and "
                    "interoperability standards is warranted."
                )
            if "trading" in domain_names:
                key_findings.append(
                    "Commercial and product-trading indicators detected. "
                    "Relevant for supply-chain visibility, pricing signals, "
                    "and market-structure analysis."
                )
            if "social" in domain_names:
                key_findings.append(
                    "Social / network coordination patterns are visible. "
                    "Useful for understanding information flow and collective attention."
                )
            if "satellite_ai" in domain_names:
                key_findings.append(
                    "Satellite / orbital / space-based AI infrastructure signals present. "
                    "Relevant to global sensing, connectivity, and future compute layers."
                )

            source_types = set(i.source_type for i in items)
            if len(source_types) >= 2:
                key_findings.append(
                    f"Multi-source corroboration observed across: {', '.join(sorted(source_types))}."
                )
            else:
                key_findings.append(
                    "Limited source-type diversity; treat conclusions as provisional."
                )

            analysis = {
                "topic": topic,
                "item_count": len(items),
                "average_confidence": round(avg_conf, 3),
                "sync_quality": calibrated.sync_quality,
                "active_domains": domain_names,
                "source_types": sorted(list(source_types)),
                "themes": domain_names or ["general"],
            }

            context["key_findings"] = key_findings
            context["raw_analysis"] = analysis
            context["analysis_confidence"] = round(
                min(0.93, avg_conf * 0.85 + calibrated.sync_quality * 0.15), 3
            )
            context["active_domains"] = domain_names

            traces.append(
                self.trace(
                    action="completed_analysis",
                    details=f"Domains={domain_names}; findings={len(key_findings)}",
                    confidence=context["analysis_confidence"],
                )
            )
            context["trace"] = traces
            self._mark_idle()
            return context

        except Exception as e:
            self._mark_error()
            traces.append(self.trace(action="analysis_failed", details=str(e)))
            context["trace"] = traces
            context["error"] = f"AnalysisAgent failed: {e}"
            return context
