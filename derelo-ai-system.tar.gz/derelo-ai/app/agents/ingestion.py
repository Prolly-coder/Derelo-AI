from __future__ import annotations

from typing import Any, Dict

from app.agents.base import BaseAgent
from app.core.search import gather_sources
from app.models.schemas import DataSource


class IngestionAgent(BaseAgent):
    name = "IngestionAgent"
    role = "Data Collection"
    description = (
        "Collects relevant items from real web and news sources "
        "(with graceful fallback). Primary entry point for live data."
    )

    async def run(self, context: Dict[str, Any]) -> Dict[str, Any]:
        self._mark_running()
        topic = context.get("topic", "")
        sources = context.get("sources", [DataSource.web, DataSource.news])
        max_items = context.get("max_items", 8)
        traces = context.get("trace", [])

        source_names = [s.value if hasattr(s, "value") else str(s) for s in sources]

        try:
            items = await gather_sources(
                topic=topic,
                sources=source_names,
                max_items=max_items,
            )

            traces.append(
                self.trace(
                    action="ingested_sources",
                    details=f"Collected {len(items)} items (sources={source_names})",
                    confidence=0.85 if items else 0.3,
                )
            )

            context["raw_items"] = items
            context["trace"] = traces
            self._mark_idle()
            return context

        except Exception as e:
            self._mark_error()
            traces.append(self.trace(action="ingestion_failed", details=str(e)))
            context["trace"] = traces
            context["error"] = f"IngestionAgent failed: {e}"
            return context
