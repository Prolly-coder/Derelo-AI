from __future__ import annotations

from typing import Any, Dict

from app.agents.base import BaseAgent


class QualityAgent(BaseAgent):
    name = "QualityAgent"
    role = "Provenance & Confidence Control"
    description = "Evaluates data quality, consistency, and overall report confidence"

    async def run(self, context: Dict[str, Any]) -> Dict[str, Any]:
        self._mark_running()
        traces = context.get("trace", [])

        try:
            sync_quality = context.get("sync_quality", 0.0)
            analysis_conf = context.get("analysis_confidence", 0.0)
            items = context.get("calibrated").items if context.get("calibrated") else []

            # Quality heuristics
            source_diversity = len(set(i.source_type for i in items)) if items else 0
            diversity_score = min(1.0, source_diversity / 3.0)

            overall = round(
                (0.35 * sync_quality) + (0.45 * analysis_conf) + (0.20 * diversity_score),
                3,
            )

            context["confidence"] = overall

            notes = []
            if sync_quality < 0.7:
                notes.append("Synchronization quality is below preferred threshold.")
            if analysis_conf < 0.7:
                notes.append("Analysis confidence is moderate; treat findings as provisional.")
            if source_diversity < 2:
                notes.append("Limited source-type diversity detected.")

            context["quality_notes"] = notes

            traces.append(
                self.trace(
                    action="quality_assessment",
                    details=f"overall_confidence={overall}; notes={notes or 'none'}",
                    confidence=overall,
                )
            )
            context["trace"] = traces
            self._mark_idle()
            return context

        except Exception as e:
            self._mark_error()
            traces.append(self.trace(action="quality_failed", details=str(e)))
            context["trace"] = traces
            context["error"] = f"QualityAgent failed: {e}"
            return context
