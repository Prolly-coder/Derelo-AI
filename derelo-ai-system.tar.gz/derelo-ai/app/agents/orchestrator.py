from __future__ import annotations

import time
from typing import Dict, Any, List
from uuid import uuid4, UUID

from app.agents.ingestion import IngestionAgent
from app.agents.sync_agent import SyncAgent
from app.agents.analysis import AnalysisAgent
from app.agents.quality import QualityAgent
from app.agents.report import ReportAgent
from app.agents.domain_agents import (
    RegulationAgent,
    DataSharingAgent,
    TradingAgent,
    SocialAgent,
)
from app.core.sync import utc_now
from app.core.storage import save_report, get_report, list_reports, init_db
from app.models.schemas import (
    LiveReport,
    ReportStatus,
    ReportRequest,
    AgentInfo,
)


class Orchestrator:
    """Coordinates the full Derelo AI multi-agent team."""

    def __init__(self):
        self.ingestion = IngestionAgent()
        self.sync = SyncAgent()
        self.analysis = AnalysisAgent()
        self.quality = QualityAgent()
        self.report_agent = ReportAgent()

        self.regulation = RegulationAgent()
        self.data_sharing = DataSharingAgent()
        self.trading = TradingAgent()
        self.social = SocialAgent()

        self._core_agents = [
            self.ingestion,
            self.sync,
            self.analysis,
            self.quality,
            self.report_agent,
        ]
        self._domain_agents = [
            self.regulation,
            self.data_sharing,
            self.trading,
            self.social,
        ]
        self._all_agents = self._core_agents + self._domain_agents
        self._db_ready = False

    async def ensure_db(self):
        if not self._db_ready:
            await init_db()
            self._db_ready = True

    def list_agents(self) -> List[AgentInfo]:
        return [
            AgentInfo(
                name=a.name,
                role=a.role,
                status=a.status,
                last_active=a.last_active,
                description=a.description,
            )
            for a in self._all_agents
        ]

    async def produce_report(self, request: ReportRequest) -> LiveReport:
        await self.ensure_db()

        report_id = uuid4()
        created_at = utc_now()

        context: Dict[str, Any] = {
            "report_id": report_id,
            "topic": request.topic,
            "sources": request.sources,
            "max_items": request.max_items,
            "depth": request.depth,
            "require_sync": request.require_sync,
            "created_at": created_at,
            "trace": [],
            "_start_perf": time.perf_counter(),
        }

        for agent in [self.ingestion, self.sync, self.analysis]:
            context = await agent.run(context)
            if context.get("error"):
                return await self._fail(report_id, request.topic, created_at, context)

        for agent in self._domain_agents:
            context = await agent.run(context)
            if context.get("error"):
                return await self._fail(report_id, request.topic, created_at, context)

        for agent in [self.quality, self.report_agent]:
            context = await agent.run(context)
            if context.get("error"):
                return await self._fail(report_id, request.topic, created_at, context)

        final_report: LiveReport = context["report"]
        await save_report(final_report)
        return final_report

    async def _fail(self, report_id, topic, created_at, context) -> LiveReport:
        failed = LiveReport(
            report_id=report_id,
            topic=topic,
            status=ReportStatus.failed,
            created_at=created_at,
            completed_at=utc_now(),
            error=context.get("error"),
            agent_trace=context.get("trace", []),
        )
        await save_report(failed)
        return failed

    async def get_report(self, report_id: UUID) -> LiveReport | None:
        await self.ensure_db()
        return await get_report(report_id)

    async def list_reports(self, limit: int = 20) -> List[LiveReport]:
        await self.ensure_db()
        return await list_reports(limit=limit)


orchestrator = Orchestrator()
