from __future__ import annotations

from typing import Any, Dict
import time

from app.agents.base import BaseAgent
from app.core.sync import calibrate_items


class SyncAgent(BaseAgent):
    name = "SyncAgent"
    role = "Synchronization & Calibration"
    description = "Applies timestamps, measures latency, and scores synchronization quality"

    async def run(self, context: Dict[str, Any]) -> Dict[str, Any]:
        self._mark_running()
        traces = context.get("trace", [])
        start_time = context.get("_start_perf", time.perf_counter())

        try:
            raw_items = context.get("raw_items", [])
            calibrated = calibrate_items(raw_items, start_time)

            context["calibrated"] = calibrated
            context["sync_quality"] = calibrated.sync_quality

            traces.append(
                self.trace(
                    action="calibrated_package",
                    details=f"sync_quality={calibrated.sync_quality}, "
                            f"max_latency_ms={calibrated.max_latency_ms}",
                    confidence=calibrated.sync_quality,
                )
            )
            context["trace"] = traces
            self._mark_idle()
            return context

        except Exception as e:
            self._mark_error()
            traces.append(self.trace(action="sync_failed", details=str(e)))
            context["trace"] = traces
            context["error"] = f"SyncAgent failed: {e}"
            return context
