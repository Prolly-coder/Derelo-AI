"""
Lightweight automatic evaluation of generated reports.
"""

from __future__ import annotations

from typing import Any, Dict, List

from app.models.advanced import EvaluationResult
from uuid import UUID


def evaluate_report(
    report_id: UUID,
    findings: List[str],
    sources: List[Dict[str, Any]],
    sync_quality: float,
    confidence: float,
    active_domains: List[str],
) -> EvaluationResult:
    # Source coverage
    n_sources = len(sources or [])
    source_coverage = min(1.0, n_sources / 6.0)

    # Domain relevance
    domain_relevance = min(1.0, len(active_domains) / 2.0) if active_domains else 0.4

    # Factual consistency proxy (higher when sync + confidence + sources align)
    factual = round(
        0.4 * (confidence or 0.5) + 0.35 * (sync_quality or 0.5) + 0.25 * source_coverage,
        3,
    )

    overall = round(
        0.4 * factual + 0.3 * source_coverage + 0.3 * domain_relevance,
        3,
    )

    notes = []
    if n_sources < 3:
        notes.append("Low source count – consider deeper retrieval.")
    if (sync_quality or 0) < 0.7:
        notes.append("Synchronization quality below preferred threshold.")
    if not active_domains:
        notes.append("No strong domain signals detected.")
    if overall >= 0.75:
        notes.append("Report meets internal quality bar for automated release.")

    return EvaluationResult(
        report_id=report_id,
        factual_consistency=factual,
        source_coverage=round(source_coverage, 3),
        domain_relevance=round(domain_relevance, 3),
        overall=overall,
        notes=notes,
    )
