"""
Document ingestion store (text only for the prototype).
"""

from __future__ import annotations

from datetime import datetime, timezone
from typing import Dict, List, Optional
from uuid import UUID, uuid4

from app.models.advanced import DocumentInfo
from app.rag.store import index_document


_DOCS: Dict[UUID, DocumentInfo] = {}
_DOC_TEXT: Dict[UUID, str] = {}


async def add_document(filename: str, text: str, tags: Optional[List[str]] = None) -> DocumentInfo:
    doc_id = uuid4()
    info = DocumentInfo(
        document_id=doc_id,
        filename=filename,
        uploaded_at=datetime.now(timezone.utc),
        chunks=max(1, len(text) // 1200),
        tags=tags or [],
    )
    _DOCS[doc_id] = info
    _DOC_TEXT[doc_id] = text
    await index_document(str(doc_id), filename, text)
    return info


def list_documents() -> List[DocumentInfo]:
    return list(_DOCS.values())


def get_document_text(document_id: UUID) -> Optional[str]:
    return _DOC_TEXT.get(document_id)
