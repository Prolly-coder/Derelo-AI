"""
Satellite data connector for Derelo AI.

Reality check (important):
- There is no public "Google Satellites" API that streams live constellation data
  the way Starlink or commercial EO providers do.
- Google Earth Engine (GEE) is the main Google-related platform for satellite /
  Earth-observation analysis. It requires a Google Cloud project, Earth Engine
  API enabled, and authentication (service account or user OAuth).
- This module provides:
  1. A clean interface for satellite-derived context.
  2. A public-data fallback (no credentials required).
  3. Clear hooks so a real GEE client can be plugged in when credentials exist.

Set GOOGLE_EARTH_ENGINE_PROJECT / GOOGLE_APPLICATION_CREDENTIALS to enable
a real GEE path in future extensions.
"""

from __future__ import annotations

import os
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field


class SatelliteSignal(BaseModel):
    title: str
    source: str
    summary: str
    observed_at: Optional[datetime] = None
    location_hint: Optional[str] = None
    confidence: float = Field(ge=0.0, le=1.0, default=0.6)
    metadata: Dict[str, Any] = Field(default_factory=dict)


class SatelliteQuery(BaseModel):
    topic: str
    region: Optional[str] = None
    max_items: int = Field(default=5, ge=1, le=20)


class SatelliteConnector:
    def __init__(self):
        self.gee_project = os.environ.get("GOOGLE_EARTH_ENGINE_PROJECT")
        self.credentials_path = os.environ.get("GOOGLE_APPLICATION_CREDENTIALS")
        self.gee_available = bool(self.gee_project and self.credentials_path)

    @property
    def status(self) -> Dict[str, Any]:
        return {
            "provider_hooks": ["google_earth_engine", "public_eo_fallback"],
            "google_earth_engine_configured": self.gee_available,
            "note": (
                "Google Earth Engine requires a Cloud project + credentials. "
                "Without them, Derelo uses a public/synthetic EO context layer only. "
                "There is no free public 'Google Satellites' live feed API."
            ),
        }

    async def query(self, q: SatelliteQuery) -> List[SatelliteSignal]:
        """
        Return satellite-related context signals for a topic.
        Real GEE calls would go here when credentials are present.
        """
        if self.gee_available:
            # Placeholder for real ee.Initialize() + ImageCollection queries.
            # Keeping the system runnable without forcing GEE setup.
            return await self._gee_placeholder(q)
        return await self._public_fallback(q)

    async def _gee_placeholder(self, q: SatelliteQuery) -> List[SatelliteSignal]:
        now = datetime.now(timezone.utc)
        return [
            SatelliteSignal(
                title=f"GEE-ready context for: {q.topic}",
                source="google_earth_engine",
                summary=(
                    "Google Earth Engine credentials detected. "
                    "Replace this placeholder with ImageCollection / reduceRegion "
                    "queries for the requested topic and region."
                ),
                observed_at=now,
                location_hint=q.region,
                confidence=0.75,
                metadata={"mode": "gee_configured_placeholder", "project": self.gee_project},
            )
        ]

    async def _public_fallback(self, q: SatelliteQuery) -> List[SatelliteSignal]:
        """
        Lightweight context that acknowledges EO relevance without claiming
        live Google satellite access.
        """
        now = datetime.now(timezone.utc)
        region = q.region or "global"
        topic = q.topic

        signals = [
            SatelliteSignal(
                title=f"Earth-observation context relevant to '{topic}'",
                source="public_eo_context",
                summary=(
                    f"Satellite and remote-sensing data are often relevant to topics "
                    f"like '{topic}' (land use, infrastructure, environment, connectivity). "
                    f"Region focus: {region}. "
                    "Connect Google Earth Engine or a commercial EO provider for "
                    "quantitative imagery products."
                ),
                observed_at=now,
                location_hint=region,
                confidence=0.55,
                metadata={"mode": "fallback", "provider": "none"},
            ),
            SatelliteSignal(
                title="Integration path: Google Earth Engine",
                source="derelo_satellite_layer",
                summary=(
                    "To incorporate Google-related satellite analysis: enable Earth Engine "
                    "on a Google Cloud project, set GOOGLE_EARTH_ENGINE_PROJECT and "
                    "GOOGLE_APPLICATION_CREDENTIALS, then implement ImageCollection "
                    "queries inside SatelliteConnector._gee_placeholder."
                ),
                observed_at=now,
                confidence=0.9,
                metadata={"docs": "https://earthengine.google.com/"},
            ),
        ]
        return signals[: q.max_items]


satellite_connector = SatelliteConnector()
