"""
LLM interface for Derelo AI — patched for xAI / Grok.

Uses the official xAI API (OpenAI-compatible chat completions):
  POST https://api.x.ai/v1/chat/completions

Configure with one of:
  export XAI_API_KEY="xai-..."
  export DERELO_LLM_API_KEY="xai-..."   # alias

Optional:
  export DERELO_LLM_BASE_URL="https://api.x.ai/v1"
  export DERELO_LLM_MODEL="grok-4.5"    # or grok-4, etc.

Without a key, Derelo falls back to heuristic analysis (fully offline-capable).
This does not make xAI a co-founder or grant special access — it is a normal
customer API integration.
"""

from __future__ import annotations

import json
import os
import re
from typing import Any, Dict, List, Optional

import httpx


class LLMInterface:
    def __init__(self):
        self.api_key = os.environ.get("DERELO_LLM_API_KEY") or os.environ.get("XAI_API_KEY")
        self.base_url = os.environ.get("DERELO_LLM_BASE_URL", "https://api.x.ai/v1").rstrip("/")
        self.model = os.environ.get("DERELO_LLM_MODEL", "grok-4.5")
        self.enabled = bool(self.api_key)
        self.timeout = float(os.environ.get("DERELO_LLM_TIMEOUT", "90"))

    @property
    def configured(self) -> bool:
        return self.enabled

    def status(self) -> Dict[str, Any]:
        return {
            "provider": "xAI / Grok",
            "configured": self.enabled,
            "base_url": self.base_url,
            "model": self.model,
            "note": (
                "Set XAI_API_KEY or DERELO_LLM_API_KEY to enable live Grok analysis. "
                "Get a key at https://console.x.ai/"
            ),
        }

    async def analyze(
        self,
        topic: str,
        sources: List[Dict[str, Any]],
        rag_context: str = "",
    ) -> Dict[str, Any]:
        if not self.enabled:
            return {
                "llm_used": False,
                "summary_extension": None,
                "extra_findings": [],
                "note": (
                    "Grok/xAI not configured – heuristic analysis only. "
                    "Set XAI_API_KEY or DERELO_LLM_API_KEY to enable."
                ),
            }

        prompt = self._build_prompt(topic, sources, rag_context)
        try:
            content = await self._chat(prompt)
            return self._parse_response(content, topic)
        except Exception as e:
            return {
                "llm_used": False,
                "summary_extension": None,
                "extra_findings": [],
                "note": f"Grok API call failed: {e}. Falling back to heuristics.",
                "error": str(e),
            }

    def _build_prompt(
        self,
        topic: str,
        sources: List[Dict[str, Any]],
        rag_context: str,
    ) -> str:
        source_lines = []
        for i, s in enumerate(sources[:12], 1):
            title = s.get("title") or s.get("name") or "source"
            snippet = (s.get("snippet") or s.get("summary") or "")[:400]
            url = s.get("url") or ""
            source_lines.append(f"{i}. {title}\n   {snippet}\n   {url}")

        sources_block = "\n".join(source_lines) if source_lines else "(no structured sources)"
        rag_block = rag_context[:3000] if rag_context else "(none)"

        return f"""You are an analytical assistant for Derelo AI, focused on rigorous, truth-seeking reports.

Topic: {topic}

Calibrated sources:
{sources_block}

Additional context (RAG / satellite / prior reports):
{rag_block}

Task:
1. Write a concise executive summary (2-4 sentences).
2. List 4-8 key findings as short bullet points. Prefer evidence-linked statements.
3. Note primary domains if clear (regulation, data_sharing, trading, social, satellite_ai).
4. Flag uncertainty where sources are thin.

Respond in this exact format:
SUMMARY:
<text>

FINDINGS:
- <finding 1>
- <finding 2>
...

DOMAINS:
<comma-separated domains or "general">
"""

    async def _chat(self, user_content: str) -> str:
        url = f"{self.base_url}/chat/completions"
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
        }
        payload = {
            "model": self.model,
            "messages": [
                {
                    "role": "system",
                    "content": (
                        "You are Grok, assisting Derelo AI with structured analytical reports. "
                        "Be precise, skeptical of weak evidence, and clear about uncertainty."
                    ),
                },
                {"role": "user", "content": user_content},
            ],
            "temperature": 0.3,
        }

        async with httpx.AsyncClient(timeout=self.timeout) as client:
            resp = await client.post(url, headers=headers, json=payload)
            resp.raise_for_status()
            data = resp.json()

        # OpenAI-compatible shape
        choices = data.get("choices") or []
        if choices:
            msg = choices[0].get("message") or {}
            content = msg.get("content")
            if content:
                return content

        # Fallback shapes
        if "output" in data:
            return str(data["output"])
        raise RuntimeError(f"Unexpected xAI response shape: {list(data.keys())}")

    def _parse_response(self, content: str, topic: str) -> Dict[str, Any]:
        summary = None
        findings: List[str] = []
        domains: List[str] = []

        # SUMMARY
        m = re.search(
            r"SUMMARY:\s*(.+?)(?=\n\s*FINDINGS:|\n\s*DOMAINS:|\Z)",
            content,
            re.IGNORECASE | re.DOTALL,
        )
        if m:
            summary = m.group(1).strip()

        # FINDINGS bullets
        fm = re.search(
            r"FINDINGS:\s*(.+?)(?=\n\s*DOMAINS:|\Z)",
            content,
            re.IGNORECASE | re.DOTALL,
        )
        if fm:
            for line in fm.group(1).splitlines():
                line = line.strip()
                if line.startswith(("-", "*", "•")):
                    findings.append(line.lstrip("-*• ").strip())
                elif line and not line.upper().startswith("DOMAINS"):
                    findings.append(line)

        # DOMAINS
        dm = re.search(r"DOMAINS:\s*(.+)", content, re.IGNORECASE)
        if dm:
            raw = dm.group(1).strip()
            domains = [d.strip() for d in re.split(r"[,;]", raw) if d.strip() and d.strip().lower() != "general"]

        if not summary and not findings:
            # Use whole response as summary extension
            summary = content.strip()[:800]
            findings = [
                f"Grok ({self.model}) analysis completed for '{topic}'.",
                "Parse structured fields failed; full model output retained in summary_extension.",
            ]

        return {
            "llm_used": True,
            "summary_extension": summary,
            "extra_findings": findings[:10],
            "domains": domains,
            "model": self.model,
            "note": f"Live Grok analysis via xAI API (model={self.model}).",
        }


llm = LLMInterface()
