from pathlib import Path

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates

from app.api.routes import router
from app.api.advanced_routes import router as advanced_router
from app.api.satellite_social_routes import router as sat_social_router
from app.core.config import settings
from app.core.encryption import encryption
from app.llm.interface import llm

BASE_DIR = Path(__file__).resolve().parent
templates = Jinja2Templates(directory=str(BASE_DIR / "templates"))

app = FastAPI(
    title="Derelo AI",
    description=(
        "Derelo AI v0.2 – Ready-to-run multi-agent intelligence platform.\n\n"
        "Capabilities: live web/news reports, domain agents (regulation, data sharing, "
        "trading, social), RAG over reports & documents, LLM-ready analysis, "
        "document ingestion, topic monitors, alerts, automatic evaluation, "
        "API-key auth, encryption at rest, web dashboard.\n\n"
        "Aligned with truth-seeking and rigorous analysis principles."
    ),
    version="0.2.0",
    docs_url="/docs",
    redoc_url="/redoc",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(router, prefix=settings.api_prefix)
app.include_router(advanced_router, prefix=settings.api_prefix)
app.include_router(sat_social_router, prefix=settings.api_prefix)
app.include_router(router)
app.include_router(advanced_router)
app.include_router(sat_social_router)


@app.on_event("startup")
async def startup():
    from app.agents.orchestrator import orchestrator
    from app.rag.store import init_rag_db
    await orchestrator.ensure_db()
    await init_rag_db()


@app.get("/", response_class=HTMLResponse)
async def root(request: Request):
    return templates.TemplateResponse(
        request=request,
        name="dashboard.html",
        context={},
    )


@app.get("/api/info")
async def api_info():
    return {
        "name": "Derelo AI",
        "version": "0.2.0",
        "message": "Derelo AI multi-agent intelligence platform is running.",
        "docs": "/docs",
        "dashboard": "/",
        "auth": "Pass X-API-Key header.",
        "encryption_enabled": encryption.enabled,
        "llm_configured": llm.configured,
        "api_prefix": settings.api_prefix,
        "advanced_endpoints": [
            "POST /v1/reports/advanced",
            "POST /v1/rag/query",
            "POST /v1/documents",
            "GET  /v1/documents",
            "POST /v1/monitors",
            "GET  /v1/monitors",
            "GET  /v1/alerts",
            "GET  /v1/capabilities",
        ],
    }
