"""
Satellite connector + internal social (posts & reactions) API routes.
"""

from __future__ import annotations

from typing import List
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, Query

from app.core.auth import require_read, require_write, APIKeyRecord
from app.satellite.connector import satellite_connector, SatelliteQuery, SatelliteSignal
from app.social.store import (
    PostCreate,
    PostInfo,
    ReactionCreate,
    create_post,
    list_posts,
    get_post,
    add_reaction,
    delete_post,
)


router = APIRouter(tags=["satellite", "social"])


# ── Satellite ────────────────────────────────────────────────────────────

@router.get("/satellite/status")
async def satellite_status(auth: APIKeyRecord = Depends(require_read)):
    return satellite_connector.status


@router.post("/satellite/query", response_model=List[SatelliteSignal])
async def satellite_query(
    body: SatelliteQuery,
    auth: APIKeyRecord = Depends(require_read),
):
    """
    Query satellite / Earth-observation context for a topic.
    Uses Google Earth Engine path when credentials are configured;
    otherwise returns an honest public/fallback context layer.
    """
    return await satellite_connector.query(body)


# ── Social posts & reactions ─────────────────────────────────────────────

@router.post("/social/posts", response_model=PostInfo, status_code=201)
async def create_social_post(
    body: PostCreate,
    auth: APIKeyRecord = Depends(require_write),
):
    """Create an internal Derelo social post (optionally linked to a report)."""
    return create_post(body)


@router.get("/social/posts", response_model=List[PostInfo])
async def list_social_posts(
    limit: int = Query(30, ge=1, le=100),
    auth: APIKeyRecord = Depends(require_read),
):
    return list_posts(limit=limit)


@router.get("/social/posts/{post_id}", response_model=PostInfo)
async def get_social_post(
    post_id: UUID,
    auth: APIKeyRecord = Depends(require_read),
):
    post = get_post(post_id)
    if not post:
        raise HTTPException(404, "Post not found")
    return post


@router.post("/social/posts/{post_id}/reactions", response_model=PostInfo)
async def react_to_post(
    post_id: UUID,
    body: ReactionCreate,
    auth: APIKeyRecord = Depends(require_write),
):
    """
    Add or update a reaction on a post.
    Allowed: like, insightful, important, disagree.
    One reaction per user per post.
    """
    try:
        return add_reaction(post_id, body)
    except KeyError:
        raise HTTPException(404, "Post not found")
    except ValueError as e:
        raise HTTPException(400, str(e))


@router.delete("/social/posts/{post_id}")
async def remove_post(
    post_id: UUID,
    auth: APIKeyRecord = Depends(require_write),
):
    if not delete_post(post_id):
        raise HTTPException(404, "Post not found")
    return {"status": "deleted"}
