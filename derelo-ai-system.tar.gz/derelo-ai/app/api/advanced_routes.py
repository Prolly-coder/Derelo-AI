"""
Advanced API surface for Derelo AI v0.2 – ready-to-run concept.
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional
from uuid import UUID

from fastapi import APIRouter, Depends, File, Form, HTTPException, Query, UploadFile

from app.core.auth import require_read, require_write, require_admin, APIKeyRecord
from app.core.encryption import encryption
from app.llm.interface import llm
from app.models.advanced import (
    AdvancedReportRequest,
    EnhancedLiveReport,
    DocumentUploadResponse,
    DocumentInfo,
    MonitorCreate,
    MonitorInfo,
    AlertInfo,
    RAGQuery,
    RAGResponse,
    EvaluationResult,
    SystemCapabilities,
    CapabilityInfo,
    ReportTemplate,
)
from app.rag.store import search as rag_search, init_rag_db
from app.scheduling import monitors as mon
from app.alerts import store as alert_store
from app.documents import store as doc_store
from app.agents.orchestrator import orchestrator
from app.evaluation.scorer import evaluate_report
from app.models.schemas import ReportRequest, DataSource
from app.satellite.connector import satellite_connector, SatelliteQuery


router = APIRouter(tags=["advanced"])


# ── Capabilities ─────────────────────────────────────────────────────────

@router.get("/capabilities", response_model=SystemCapabilities)
async def capabilities():
    return SystemCapabilities(
        version="0.2.0",
        llm_configured=llm.configured,
        encryption_enabled=encryption.enabled,
        rag_enabled=True,
        capabilities=[
            CapabilityInfo(name="multi_agent_reports", status="available", description="Core multi-agent live reports"),
            CapabilityInfo(name="real_web_news_search", status="available", description="Live web & news ingestion"),
            CapabilityInfo(name="domain_agents", status="available", description="Regulation, data sharing, trading, social"),
            CapabilityInfo(name="rag", status="available", description="Retrieval over past reports & documents"),
            CapabilityInfo(name="llm_analysis", status="available", description="xAI/Grok API integration; set XAI_API_KEY or DERELO_LLM_API_KEY"),
            CapabilityInfo(name="document_ingestion", status="available", description="Upload and index text documents"),
            CapabilityInfo(name="scheduling", status="available", description="Topic monitors with frequency"),
            CapabilityInfo(name="alerts", status="available", description="Alert store + webhook field"),
            CapabilityInfo(name="evaluation", status="available", description="Automatic report quality scoring"),
            CapabilityInfo(name="encryption_at_rest", status="available", description="Fernet encryption when key set"),
            CapabilityInfo(name="api_auth", status="available", description="API-key scopes"),
            CapabilityInfo(name="dashboard", status="available", description="Web dashboard at /"),
            CapabilityInfo(name="satellite_context", status="partial", description="EO/satellite connector; GEE when credentials set"),
            CapabilityInfo(name="social_posts_reactions", status="available", description="Internal posts + reactions feed"),
            CapabilityInfo(name="streaming", status="planned", description="SSE/WebSocket progressive reports"),
            CapabilityInfo(name="sso_billing", status="planned", description="Enterprise SSO & metering"),
        ],
    )


# ── Advanced Reports ─────────────────────────────────────────────────────

@router.post("/reports/advanced", response_model=EnhancedLiveReport, status_code=201)
async def create_advanced_report(
    body: AdvancedReportRequest,
    auth: APIKeyRecord = Depends(require_write),
):
    """
    Full-pipeline report: search → sync → analysis → domain agents →
    RAG context → optional LLM → evaluation → index for future RAG.
    """
    await init_rag_db()

    # Map to existing report request
    sources = []
    for s in body.sources:
        try:
            sources.append(DataSource(s))
        except Exception:
            sources.append(DataSource.web)

    basic_req = ReportRequest(
        topic=body.topic,
        sources=sources or [DataSource.web, DataSource.news],
        depth=body.depth,  # type: ignore
        max_items=body.max_items,
        require_sync=body.require_sync,
    )

    # RAG context
    rag_hits = []
    if body.use_rag:
        rag_hits = await rag_search(body.topic, top_k=5)
    rag_context = "\n---\n".join(h.content for h in rag_hits)

    # Satellite / EO signals (auto-wired when include_satellite=True)
    satellite_signals: List[Dict] = []
    satellite_used = False
    if body.include_satellite:
        try:
            sat_results = await satellite_connector.query(
                SatelliteQuery(
                    topic=body.topic,
                    region=body.region,
                    max_items=4,
                )
            )
            satellite_signals = [s.model_dump() for s in sat_results]
            satellite_used = True
            # Fold satellite context into RAG-style context for LLM
            sat_text = "\n".join(
                f"[Satellite/{s.get('source')}] {s.get('title')}: {s.get('summary')}"
                for s in satellite_signals
            )
            if sat_text:
                rag_context = (rag_context + "\n---\n" + sat_text).strip()
        except Exception:
            satellite_signals = []
            satellite_used = False

    # Run core pipeline
    report = await orchestrator.produce_report(basic_req)

    # LLM enrichment
    llm_result = {"llm_used": False}
    if body.use_llm:
        source_dicts = [s.model_dump() if hasattr(s, "model_dump") else s for s in (report.sources_used or [])]
        llm_result = await llm.analyze(body.topic, source_dicts, rag_context)

    findings = list(report.key_findings or [])
    if llm_result.get("extra_findings"):
        findings.extend(llm_result["extra_findings"])

    # Prefer Grok summary extension when present
    report_summary = report.summary
    if llm_result.get("summary_extension"):
        report_summary = (
            (report.summary or "") + " | Grok: " + str(llm_result["summary_extension"])
        ).strip(" |")

    # Surface satellite findings explicitly
    if satellite_signals:
        findings.append(
            f"[Satellite] Incorporated {len(satellite_signals)} Earth-observation / satellite context signal(s)."
        )
        for s in satellite_signals[:2]:
            findings.append(f"[Satellite] {s.get('title')}: {str(s.get('summary', ''))[:180]}")

    # Evaluation
    source_dicts = []
    for s in (report.sources_used or []):
        if hasattr(s, "model_dump"):
            source_dicts.append(s.model_dump())
        elif isinstance(s, dict):
            source_dicts.append(s)

    domains = []
    if report.raw_analysis and isinstance(report.raw_analysis, dict):
        domains = list(report.raw_analysis.get("active_domains") or [])
    for d in llm_result.get("domains") or []:
        if d not in domains:
            domains.append(d)

    evaluation = evaluate_report(
        report_id=report.report_id,
        findings=findings,
        sources=source_dicts,
        sync_quality=report.sync_quality or 0.0,
        confidence=report.confidence or 0.0,
        active_domains=domains,
    )

    # Index for future RAG
    try:
        from app.rag.store import index_report
        await index_report(
            str(report.report_id),
            report.topic,
            report.summary or "",
            findings,
        )
    except Exception:
        pass

    # Build enhanced response
    claims = [
        {
            "text": f,
            "source_urls": [],
            "confidence": report.confidence or 0.5,
            "domain": domains[0] if domains else None,
        }
        for f in findings[:8]
    ]

    enhanced = EnhancedLiveReport(
        report_id=report.report_id,
        topic=report.topic,
        status=report.status.value if hasattr(report.status, "value") else str(report.status),
        created_at=report.created_at,
        completed_at=report.completed_at,
        template=body.template,
        summary=report_summary,
        key_findings=findings,
        claims=claims,  # type: ignore
        sources_used=source_dicts,
        satellite_signals=satellite_signals,
        sync_quality=report.sync_quality,
        confidence=report.confidence,
        rag_hits=len(rag_hits),
        llm_used=bool(llm_result.get("llm_used")),
        satellite_used=satellite_used,
        active_domains=domains,
        agent_trace=[t.model_dump() if hasattr(t, "model_dump") else t for t in (report.agent_trace or [])],
        evaluation=evaluation.model_dump(),
        tags=body.tags,
        error=report.error,
    )
    return enhanced


# ── RAG ──────────────────────────────────────────────────────────────────

@router.post("/rag/query", response_model=RAGResponse)
async def rag_query(body: RAGQuery, auth: APIKeyRecord = Depends(require_read)):
    await init_rag_db()
    hits = await rag_search(
        body.query,
        top_k=body.top_k,
        include_reports=body.include_reports,
        include_documents=body.include_documents,
    )
    return RAGResponse(query=body.query, hits=hits)


# ── Documents ────────────────────────────────────────────────────────────

@router.post("/documents", response_model=DocumentUploadResponse, status_code=201)
async def upload_document(
    file: UploadFile = File(...),
    tags: Optional[str] = Form(None),
    auth: APIKeyRecord = Depends(require_write),
):
    content = await file.read()
    try:
        text = content.decode("utf-8", errors="ignore")
    except Exception:
        raise HTTPException(400, "Only text-decodable documents are supported in this prototype")

    tag_list = [t.strip() for t in (tags or "").split(",") if t.strip()]
    info = await doc_store.add_document(file.filename or "upload.txt", text, tag_list)
    return DocumentUploadResponse(
        document_id=info.document_id,
        filename=info.filename,
        status="indexed",
        chunks=info.chunks,
        message="Document indexed for RAG",
    )


@router.get("/documents", response_model=List[DocumentInfo])
async def list_documents(auth: APIKeyRecord = Depends(require_read)):
    return doc_store.list_documents()


# ── Monitors (Scheduling) ────────────────────────────────────────────────

@router.post("/monitors", response_model=MonitorInfo, status_code=201)
async def create_monitor(body: MonitorCreate, auth: APIKeyRecord = Depends(require_write)):
    return mon.create_monitor(body)


@router.get("/monitors", response_model=List[MonitorInfo])
async def list_monitors(auth: APIKeyRecord = Depends(require_read)):
    return mon.list_monitors()


@router.delete("/monitors/{monitor_id}")
async def delete_monitor(monitor_id: UUID, auth: APIKeyRecord = Depends(require_write)):
    if not mon.delete_monitor(monitor_id):
        raise HTTPException(404, "Monitor not found")
    return {"status": "deleted"}


# ── Alerts ───────────────────────────────────────────────────────────────

@router.get("/alerts", response_model=List[AlertInfo])
async def list_alerts(limit: int = Query(20, ge=1, le=100), auth: APIKeyRecord = Depends(require_read)):
    return alert_store.list_alerts(limit)


@router.post("/alerts/{alert_id}/acknowledge")
async def ack_alert(alert_id: UUID, auth: APIKeyRecord = Depends(require_write)):
    if not alert_store.acknowledge(alert_id):
        raise HTTPException(404, "Alert not found")
    return {"status": "acknowledged"}
