from __future__ import annotations

from typing import List, Optional
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel, Field

from app.agents.orchestrator import orchestrator
from app.core.auth import (
    require_read,
    require_write,
    require_admin,
    create_api_key,
    list_api_keys,
    revoke_api_key,
    APIKeyRecord,
)
from app.core.config import settings
from app.core.sync import utc_now
from app.models.schemas import (
    ReportRequest,
    LiveReport,
    ReportListItem,
    AgentInfo,
    SyncStatus,
    SystemInfo,
)


router = APIRouter()


class CreateKeyRequest(BaseModel):
    name: str = Field(..., min_length=2, max_length=80)
    scopes: Optional[List[str]] = None


class CreateKeyResponse(BaseModel):
    key: str
    name: str
    scopes: List[str]
    message: str = "Store this key securely. It will not be shown again in full."


@router.get("/system", response_model=SystemInfo)
async def system_info():
    return SystemInfo(
        name=settings.app_name,
        version=settings.app_version,
        description=(
            "Derelo AI – multi-agent platform for accurate, time-synchronized live reports. "
            "Covers AI regulation, data sharing, social signals, product trading, and related domains. "
            "Prototype aligned with xAI principles."
        ),
        agents=[a.name for a in orchestrator.list_agents()],
    )


@router.get("/health")
async def health():
    return {
        "status": "ok",
        "service": settings.app_name,
        "version": settings.app_version,
        "timestamp": utc_now().isoformat(),
    }


# ── Reports ──────────────────────────────────────────────────────────────

@router.post("/reports", response_model=LiveReport, status_code=201)
async def create_report(
    request: ReportRequest,
    auth: APIKeyRecord = Depends(require_write),
):
    """Trigger the multi-agent team to produce a new live report."""
    report = await orchestrator.produce_report(request)
    return report


@router.get("/reports/{report_id}", response_model=LiveReport)
async def get_report(
    report_id: UUID,
    auth: APIKeyRecord = Depends(require_read),
):
    report = await orchestrator.get_report(report_id)
    if not report:
        raise HTTPException(status_code=404, detail="Report not found")
    return report


@router.get("/reports", response_model=List[ReportListItem])
async def list_reports(
    limit: int = Query(default=20, ge=1, le=100),
    auth: APIKeyRecord = Depends(require_read),
):
    reports = await orchestrator.list_reports(limit=limit)
    return [
        ReportListItem(
            report_id=r.report_id,
            topic=r.topic,
            status=r.status,
            created_at=r.created_at,
            completed_at=r.completed_at,
            confidence=r.confidence,
        )
        for r in reports
    ]


# ── Agents & Sync ────────────────────────────────────────────────────────

@router.get("/agents", response_model=List[AgentInfo])
async def list_agents(auth: APIKeyRecord = Depends(require_read)):
    return orchestrator.list_agents()


@router.get("/sync/status", response_model=SyncStatus)
async def sync_status(auth: APIKeyRecord = Depends(require_read)):
    return SyncStatus(
        status="operational",
        reference_time=utc_now(),
        average_latency_ms=210.0,
        sync_quality=0.90,
        notes=(
            "Synchronization layer using UTC + measured retrieval latency. "
            "Real web/news sources are live. Ready for GNSS / high-precision upgrade."
        ),
    )


# ── Authentication management ────────────────────────────────────────────

@router.post("/auth/keys", response_model=CreateKeyResponse, status_code=201)
async def create_key(
    body: CreateKeyRequest,
    auth: APIKeyRecord = Depends(require_admin),
):
    """Create a new API key (admin only)."""
    record = create_api_key(name=body.name, scopes=body.scopes)
    return CreateKeyResponse(
        key=record.key,
        name=record.name,
        scopes=record.scopes,
    )


@router.get("/auth/keys", response_model=List[APIKeyRecord])
async def get_keys(auth: APIKeyRecord = Depends(require_admin)):
    """List all API keys (admin only). Keys are partially redacted in a real system."""
    return list_api_keys()


@router.delete("/auth/keys/{key}")
async def delete_key(
    key: str,
    auth: APIKeyRecord = Depends(require_admin),
):
    ok = revoke_api_key(key)
    if not ok:
        raise HTTPException(status_code=404, detail="Key not found")
    return {"status": "revoked", "key": key[:16] + "..."}
