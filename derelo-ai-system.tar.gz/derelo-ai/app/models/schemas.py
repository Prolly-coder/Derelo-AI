from __future__ import annotations

from datetime import datetime
from enum import Enum
from typing import Any, Dict, List, Optional
from uuid import UUID

from pydantic import BaseModel, Field


class ReportDepth(str, Enum):
    quick = "quick"
    standard = "standard"
    deep = "deep"


class ReportStatus(str, Enum):
    pending = "pending"
    running = "running"
    completed = "completed"
    failed = "failed"


class AgentStatus(str, Enum):
    idle = "idle"
    running = "running"
    error = "error"


class DataSource(str, Enum):
    web = "web"
    news = "news"
    mock = "mock"          # for reliable offline demos
    custom = "custom"


class ReportRequest(BaseModel):
    topic: str = Field(..., min_length=3, max_length=300, description="Main topic or question for the live report")
    sources: List[DataSource] = Field(
        default=[DataSource.web, DataSource.news],
        description="Data sources the agents should use"
    )
    depth: ReportDepth = Field(default=ReportDepth.standard)
    max_items: int = Field(default=8, ge=1, le=30)
    require_sync: bool = Field(default=True, description="Enforce tight timestamp calibration")


class AgentTraceStep(BaseModel):
    agent: str
    action: str
    timestamp: datetime
    details: Optional[str] = None
    confidence: Optional[float] = Field(default=None, ge=0.0, le=1.0)


class SourceItem(BaseModel):
    title: str
    url: Optional[str] = None
    snippet: str
    published_at: Optional[datetime] = None
    retrieved_at: datetime
    source_type: str
    confidence: float = Field(ge=0.0, le=1.0)


class CalibratedDataPackage(BaseModel):
    items: List[SourceItem]
    calibration_timestamp: datetime
    max_latency_ms: float
    sync_quality: float = Field(ge=0.0, le=1.0, description="1.0 = excellent synchronization")


class LiveReport(BaseModel):
    report_id: UUID
    topic: str
    status: ReportStatus
    created_at: datetime
    completed_at: Optional[datetime] = None
    summary: Optional[str] = None
    key_findings: List[str] = Field(default_factory=list)
    sources_used: List[SourceItem] = Field(default_factory=list)
    sync_quality: Optional[float] = None
    confidence: Optional[float] = None
    agent_trace: List[AgentTraceStep] = Field(default_factory=list)
    raw_analysis: Optional[Dict[str, Any]] = None
    error: Optional[str] = None


class ReportListItem(BaseModel):
    report_id: UUID
    topic: str
    status: ReportStatus
    created_at: datetime
    completed_at: Optional[datetime] = None
    confidence: Optional[float] = None


class AgentInfo(BaseModel):
    name: str
    role: str
    status: AgentStatus
    last_active: Optional[datetime] = None
    description: str


class SyncStatus(BaseModel):
    layer: str = "Derelo Synchronization Layer"
    status: str
    reference_time: datetime
    average_latency_ms: float
    sync_quality: float
    notes: str


class SystemInfo(BaseModel):
    name: str = "Derelo AI"
    version: str = "0.1.0"
    description: str
    agents: List[str]
    api_version: str = "v1"
