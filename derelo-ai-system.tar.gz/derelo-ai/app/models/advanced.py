"""
Expanded schemas for Derelo AI v0.2 – full advancement concept.
"""

from __future__ import annotations

from datetime import datetime
from enum import Enum
from typing import Any, Dict, List, Optional
from uuid import UUID

from pydantic import BaseModel, Field


# ── Report enhancements ──────────────────────────────────────────────────

class ReportTemplate(str, Enum):
    executive = "executive"
    legal = "legal"
    technical = "technical"
    compliance = "compliance"
    standard = "standard"


class ReportFormat(str, Enum):
    json = "json"
    markdown = "markdown"
    summary = "summary"


class AdvancedReportRequest(BaseModel):
    topic: str = Field(..., min_length=3, max_length=500)
    sources: List[str] = Field(default=["web", "news"])
    depth: str = Field(default="standard")
    max_items: int = Field(default=8, ge=1, le=30)
    template: ReportTemplate = ReportTemplate.standard
    require_sync: bool = True
    use_rag: bool = True
    use_llm: bool = True          # when LLM backend is configured
    include_satellite: bool = True  # auto-wire satellite / EO context
    region: Optional[str] = None
    document_ids: List[UUID] = Field(default_factory=list)
    tags: List[str] = Field(default_factory=list)


class Claim(BaseModel):
    text: str
    source_urls: List[str] = Field(default_factory=list)
    confidence: float = Field(ge=0.0, le=1.0)
    domain: Optional[str] = None


class EnhancedLiveReport(BaseModel):
    report_id: UUID
    topic: str
    status: str
    created_at: datetime
    completed_at: Optional[datetime] = None
    template: ReportTemplate = ReportTemplate.standard
    summary: Optional[str] = None
    key_findings: List[str] = Field(default_factory=list)
    claims: List[Claim] = Field(default_factory=list)
    sources_used: List[Dict[str, Any]] = Field(default_factory=list)
    satellite_signals: List[Dict[str, Any]] = Field(default_factory=list)
    sync_quality: Optional[float] = None
    confidence: Optional[float] = None
    rag_hits: int = 0
    llm_used: bool = False
    satellite_used: bool = False
    active_domains: List[str] = Field(default_factory=list)
    agent_trace: List[Dict[str, Any]] = Field(default_factory=list)
    evaluation: Optional[Dict[str, Any]] = None
    tags: List[str] = Field(default_factory=list)
    error: Optional[str] = None


# ── Documents (ingestion) ────────────────────────────────────────────────

class DocumentUploadResponse(BaseModel):
    document_id: UUID
    filename: str
    status: str
    chunks: int
    message: str


class DocumentInfo(BaseModel):
    document_id: UUID
    filename: str
    uploaded_at: datetime
    chunks: int
    tags: List[str] = Field(default_factory=list)


# ── Scheduling & Monitoring ──────────────────────────────────────────────

class ScheduleFrequency(str, Enum):
    hourly = "hourly"
    daily = "daily"
    weekly = "weekly"


class MonitorCreate(BaseModel):
    name: str = Field(..., min_length=2, max_length=120)
    topic: str = Field(..., min_length=3)
    frequency: ScheduleFrequency = ScheduleFrequency.daily
    template: ReportTemplate = ReportTemplate.standard
    alert_on_confidence_below: Optional[float] = Field(default=None, ge=0.0, le=1.0)
    alert_webhook: Optional[str] = None
    enabled: bool = True


class MonitorInfo(BaseModel):
    monitor_id: UUID
    name: str
    topic: str
    frequency: ScheduleFrequency
    enabled: bool
    last_run: Optional[datetime] = None
    next_run: Optional[datetime] = None
    alert_webhook: Optional[str] = None


# ── Alerts ───────────────────────────────────────────────────────────────

class AlertInfo(BaseModel):
    alert_id: UUID
    monitor_id: Optional[UUID] = None
    report_id: Optional[UUID] = None
    severity: str
    message: str
    created_at: datetime
    acknowledged: bool = False


# ── RAG ──────────────────────────────────────────────────────────────────

class RAGQuery(BaseModel):
    query: str
    top_k: int = Field(default=5, ge=1, le=20)
    include_reports: bool = True
    include_documents: bool = True


class RAGHit(BaseModel):
    content: str
    source_type: str          # report | document
    source_id: str
    score: float


class RAGResponse(BaseModel):
    query: str
    hits: List[RAGHit]


# ── Evaluation ───────────────────────────────────────────────────────────

class EvaluationResult(BaseModel):
    report_id: UUID
    factual_consistency: float
    source_coverage: float
    domain_relevance: float
    overall: float
    notes: List[str] = Field(default_factory=list)


# ── System / Capability ──────────────────────────────────────────────────

class CapabilityInfo(BaseModel):
    name: str
    status: str               # available | partial | planned
    description: str


class SystemCapabilities(BaseModel):
    version: str = "0.2.0"
    capabilities: List[CapabilityInfo]
    llm_configured: bool
    encryption_enabled: bool
    rag_enabled: bool
