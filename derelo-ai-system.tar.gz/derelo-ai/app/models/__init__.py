# Pydantic models
