"""
Simple in-memory + SQLite-backed RAG store over reports and documents.
Production systems would use a vector database (pgvector, Pinecone, etc.).
"""

from __future__ import annotations

import json
import re
from pathlib import Path
from typing import List, Dict, Any
from uuid import UUID, uuid4
from datetime import datetime, timezone

import aiosqlite

from app.models.advanced import RAGHit


DB_PATH = Path(__file__).resolve().parents[2] / "derelo_rag.db"


def _tokenize(text: str) -> set:
    return set(re.findall(r"[a-z0-9]{3,}", text.lower()))


def _score(query_tokens: set, doc_tokens: set) -> float:
    if not query_tokens or not doc_tokens:
        return 0.0
    overlap = len(query_tokens & doc_tokens)
    return overlap / (len(query_tokens) ** 0.5 * len(doc_tokens) ** 0.5 + 1e-6)


async def init_rag_db():
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("""
            CREATE TABLE IF NOT EXISTS chunks (
                chunk_id TEXT PRIMARY KEY,
                source_type TEXT NOT NULL,
                source_id TEXT NOT NULL,
                content TEXT NOT NULL,
                created_at TEXT NOT NULL
            )
        """)
        await db.execute("""
            CREATE INDEX IF NOT EXISTS idx_chunks_source
            ON chunks(source_type, source_id)
        """)
        await db.commit()


async def add_chunk(source_type: str, source_id: str, content: str):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            "INSERT INTO chunks (chunk_id, source_type, source_id, content, created_at) VALUES (?, ?, ?, ?, ?)",
            (str(uuid4()), source_type, source_id, content[:4000], datetime.now(timezone.utc).isoformat()),
        )
        await db.commit()


async def index_report(report_id: str, topic: str, summary: str, findings: List[str]):
    text = f"Topic: {topic}\nSummary: {summary or ''}\n" + "\n".join(findings or [])
    # Simple chunking
    for i in range(0, len(text), 1200):
        await add_chunk("report", report_id, text[i:i+1200])


async def index_document(document_id: str, filename: str, text: str):
    for i in range(0, len(text), 1200):
        chunk = f"Document: {filename}\n{text[i:i+1200]}"
        await add_chunk("document", document_id, chunk)


async def search(query: str, top_k: int = 5, include_reports: bool = True, include_documents: bool = True) -> List[RAGHit]:
    q_tokens = _tokenize(query)
    hits: List[RAGHit] = []

    async with aiosqlite.connect(DB_PATH) as db:
        async with db.execute("SELECT source_type, source_id, content FROM chunks") as cur:
            rows = await cur.fetchall()

    for source_type, source_id, content in rows:
        if source_type == "report" and not include_reports:
            continue
        if source_type == "document" and not include_documents:
            continue
        score = _score(q_tokens, _tokenize(content))
        if score > 0.05:
            hits.append(RAGHit(
                content=content[:800],
                source_type=source_type,
                source_id=source_id,
                score=round(score, 4),
            ))

    hits.sort(key=lambda h: h.score, reverse=True)
    return hits[:top_k]
