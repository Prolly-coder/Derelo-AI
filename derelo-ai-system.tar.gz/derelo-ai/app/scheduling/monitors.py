"""
In-memory monitor / schedule registry.
A production system would use a job queue (Celery, ARQ, cloud scheduler).
"""

from __future__ import annotations

from datetime import datetime, timezone, timedelta
from typing import Dict, List, Optional
from uuid import UUID, uuid4

from app.models.advanced import MonitorCreate, MonitorInfo, ScheduleFrequency


_MONITORS: Dict[UUID, MonitorInfo] = {}


def _next_run(freq: ScheduleFrequency, from_time: Optional[datetime] = None) -> datetime:
    now = from_time or datetime.now(timezone.utc)
    if freq == ScheduleFrequency.hourly:
        return now + timedelta(hours=1)
    if freq == ScheduleFrequency.weekly:
        return now + timedelta(days=7)
    return now + timedelta(days=1)


def create_monitor(body: MonitorCreate) -> MonitorInfo:
    mid = uuid4()
    info = MonitorInfo(
        monitor_id=mid,
        name=body.name,
        topic=body.topic,
        frequency=body.frequency,
        enabled=body.enabled,
        last_run=None,
        next_run=_next_run(body.frequency),
        alert_webhook=body.alert_webhook,
    )
    _MONITORS[mid] = info
    return info


def list_monitors() -> List[MonitorInfo]:
    return list(_MONITORS.values())


def get_monitor(monitor_id: UUID) -> Optional[MonitorInfo]:
    return _MONITORS.get(monitor_id)


def delete_monitor(monitor_id: UUID) -> bool:
    return _MONITORS.pop(monitor_id, None) is not None


def mark_run(monitor_id: UUID):
    m = _MONITORS.get(monitor_id)
    if m:
        now = datetime.now(timezone.utc)
        # recreate with updated times (MonitorInfo is immutable-ish)
        updated = MonitorInfo(
            monitor_id=m.monitor_id,
            name=m.name,
            topic=m.topic,
            frequency=m.frequency,
            enabled=m.enabled,
            last_run=now,
            next_run=_next_run(m.frequency, now),
            alert_webhook=m.alert_webhook,
        )
        _MONITORS[monitor_id] = updated
