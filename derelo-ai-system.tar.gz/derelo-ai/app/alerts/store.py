"""
Simple alert store.
"""

from __future__ import annotations

from datetime import datetime, timezone
from typing import List, Optional
from uuid import UUID, uuid4

from app.models.advanced import AlertInfo


_ALERTS: List[AlertInfo] = []


def create_alert(
    message: str,
    severity: str = "info",
    monitor_id: Optional[UUID] = None,
    report_id: Optional[UUID] = None,
) -> AlertInfo:
    alert = AlertInfo(
        alert_id=uuid4(),
        monitor_id=monitor_id,
        report_id=report_id,
        severity=severity,
        message=message,
        created_at=datetime.now(timezone.utc),
        acknowledged=False,
    )
    _ALERTS.insert(0, alert)
    return alert


def list_alerts(limit: int = 50) -> List[AlertInfo]:
    return _ALERTS[:limit]


def acknowledge(alert_id: UUID) -> bool:
    for a in _ALERTS:
        if a.alert_id == alert_id:
            # mutable update
            object.__setattr__(a, "acknowledged", True)
            return True
    return False
