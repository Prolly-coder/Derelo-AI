#!/usr/bin/env python3
"""
Simple demo script for Derelo AI.
Run after starting the server, or use it to exercise the orchestrator directly.
"""

import asyncio
import json
from app.agents.orchestrator import orchestrator
from app.models.schemas import ReportRequest, DataSource, ReportDepth


async def main():
    print("=== Derelo AI – Live Report Demo ===\n")

    request = ReportRequest(
        topic="AI technology regulation and data sharing developments",
        sources=[DataSource.web, DataSource.news],
        depth=ReportDepth.standard,
        max_items=6,
    )

    print(f"Topic: {request.topic}")
    print("Running multi-agent pipeline...\n")

    report = await orchestrator.produce_report(request)

    print(f"Report ID   : {report.report_id}")
    print(f"Status      : {report.status}")
    print(f"Confidence  : {report.confidence}")
    print(f"Sync Quality: {report.sync_quality}")
    print("\n--- Summary ---")
    print(report.summary)
    print("\n--- Key Findings ---")
    for i, finding in enumerate(report.key_findings, 1):
        print(f"{i}. {finding}")
    print("\n--- Agent Trace ---")
    for step in report.agent_trace:
        conf = f" (conf={step.confidence})" if step.confidence is not None else ""
        print(f"[{step.timestamp.isoformat()}] {step.agent}: {step.action}{conf}")
        if step.details:
            print(f"    → {step.details}")

    print("\n=== Demo complete ===")


if __name__ == "__main__":
    asyncio.run(main())
